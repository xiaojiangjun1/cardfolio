const path=require('path'),fs=require('fs');
function dependency(name){try{return require(name)}catch{const modules=process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES||path.resolve(path.dirname(process.execPath),'..','node_modules');return require(path.join(modules,name))}}
function launchOptions(){const executablePath=process.env.CHROMIUM_EXECUTABLE||'C:/Program Files/Google/Chrome/Application/chrome.exe';return {headless:true,...(fs.existsSync(executablePath)?{executablePath}:{})}}
module.exports={dependency,launchOptions};
