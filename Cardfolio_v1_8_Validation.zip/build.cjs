// Deterministic additive transformation from the only authorized baseline.
const fs=require('fs'),path=require('path'),crypto=require('crypto');
const baseline=fs.readFileSync('baseline/Cardfolio_v1_7_4.html','utf8');let s=baseline;
function replace(a,b){if(!s.includes(a))throw Error('Missing baseline anchor: '+a.slice(0,90));s=s.replace(a,b)}
replace('<meta name="viewport" content="width=device-width,initial-scale=1" />','<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover" />\n<meta name="theme-color" content="#101c36" />\n<meta name="apple-mobile-web-app-capable" content="yes" />\n<meta name="apple-mobile-web-app-status-bar-style" content="default" />\n<meta name="apple-mobile-web-app-title" content="Cardfolio" />\n<meta name="referrer" content="no-referrer" />\n<script>if(/^https?:$/.test(location.protocol)){for(const [rel,href] of [["manifest","./manifest.webmanifest"],["icon","./icons/icon-192.png"],["apple-touch-icon","./icons/apple-touch-icon.png"]]){const link=document.createElement("link");link.rel=rel;link.href=href;document.head.appendChild(link)}}<\/script>');
replace('<title>Cardfolio v1.7.4 · 可靠性与性能修复</title>','<title>Cardfolio v1.8 · Desktop + Mobile + PWA</title>');
replace('</style>',fs.readFileSync('src/mobile.css','utf8')+'\n</style>');
replace('<section id="data" class="screen"></section>','<section id="data" class="screen"></section>\n  <section id="more" class="screen"></section>');
replace('<div id="storage-status"','<div id="pwa-notice" class="pwa-notice" role="status"></div>\n  <div id="storage-status"');
const icons=['<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>','<rect x="2" y="5" width="20" height="15" rx="3"/><path d="M2 10h20M6 15h4"/>','<path d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1.1 6.2-5.6-3-5.6 3 1.1-6.2L3 9.6l6.2-.9Z"/>','<path d="M5 20V10M12 20V4M19 20v-7"/>','<circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/>'];
const tabs=['overview','cards','ledger','visuals','more'],labels=['总览','信用卡','奖励','积分','更多'];
replace('<div id="modal-root"></div>','<nav class="mobile-nav" aria-label="主要导航">'+tabs.map((t,i)=>`<button type="button" data-tab="${t}" aria-label="${labels[i]}"><svg viewBox="0 0 24 24" aria-hidden="true">${icons[i]}</svg><span>${labels[i]}</span></button>`).join('')+'</nav>\n<div id="modal-root"></div>\n<div id="toast" class="toast" role="status" aria-live="polite"></div>');
replace('function renderOverview(){','function renderOverview(){\n if(isCompact()){renderMobileOverview();return}');
replace('const results=`<section class="outline section"><div class="table-wrap"><table><thead><tr><th>实际入账 / 产品变动日期</th>','const results=isCompact()?mobileLedger(page,ev):`<section class="outline section"><div class="table-wrap"><table><thead><tr><th>实际入账 / 产品变动日期</th>');
replace("const renderers={overview:renderOverview,","const renderers={more:renderMore,overview:renderOverview,");
replace("function setTab(next){tab=next;","function setTab(next){if(!titles[next])return;tab=next;document.body.dataset.page=next;syncMobileNav();");
replace("$('#data').insertAdjacentHTML('afterbegin',recoveryPanel());","$('#data').insertAdjacentHTML('afterbegin',backupPanel()+recoveryPanel());");
replace('Cardfolio · 离线单文件 v1.7.4（可靠性与性能修复）','Cardfolio v1.8 · Desktop / Mobile / PWA');
replace("function closeModal(){const wasOpen=","function closeModal(force=true){if(!force&&!confirmDiscard())return;modalDirty=false;document.body.classList.remove('modal-open');$('.app').inert=false;$('.mobile-nav').inert=false;const wasOpen=");
replace("else if(act==='close-modal')closeModal();","else if(act==='close-modal')closeModal(false);");
replace("if(e.key==='Escape')closeModal()","if(e.key==='Escape')closeModal(false)");
replace("if(e.target.classList.contains('modal-backdrop'))closeModal()","if(e.target.classList.contains('modal-backdrop'))closeModal(false)");
replace("function wrapModal(title,body,foot=''){","function wrapModal(title,body,foot=''){modalDirty=false;");
replace("if(!runtime.loadIssue)localStorage.setItem(BACKUP_KEY,current);","if(!runtime.loadIssue)localStorage.setItem(BACKUP_KEY,current);");
// Feedback only after a successful commit; do not clear drafts on failed saves.
replace("try{after()}catch(err)","try{after();toast('已保存到本机')}catch(err)");
replace("type=\"${type}\" value=\"${esc(value)}\" ${extra}","type=\"${type}\" value=\"${esc(value)}\" ${type==='number'?'inputmode=\"decimal\"':''} ${extra}");
replace("function exportJSON(){download(JSON.stringify({...data,exportedAt:new Date().toISOString()},null,2),`cardfolio-backup-${TODAY()}.json`,'application/json')}","function exportJSON(){try{download(JSON.stringify({...data,exportedAt:new Date().toISOString()},null,2),`cardfolio-backup-${TODAY()}.json`,'application/json');noteBackup()}catch(err){alert('导出未完成：'+err.message)}}");
replace('setTimeout(()=>URL.revokeObjectURL(url),1000)','setTimeout(()=>URL.revokeObjectURL(url),60000)');
replace("invalidate();setTab('overview');",fs.readFileSync('src/additions.js','utf8')+"\ninvalidate();setTab('overview');");
fs.mkdirSync('cardfolio/icons',{recursive:true});fs.writeFileSync('cardfolio/index.html',s);fs.writeFileSync('Cardfolio_v1_8_Offline.html',s);
fs.mkdirSync('artifacts',{recursive:true});fs.writeFileSync('artifacts/provenance.json',JSON.stringify({baseline:'Cardfolio_v1_7_4.html',bytes:Buffer.byteLength(baseline),sha256:crypto.createHash('sha256').update(baseline).digest('hex'),outputBytes:Buffer.byteLength(s)},null,2));
console.log('Built v1.8 from v1.7.4; '+Buffer.byteLength(s)+' bytes');
