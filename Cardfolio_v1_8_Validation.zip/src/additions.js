// v1.8 additive views and application shell. No business schema or accounting changes.
const compactMedia=matchMedia('(max-width:1023px)');
function isCompact(){return compactMedia.matches}
titles.more=['YOUR CARDFOLIO','更多','家庭、权益、时间线与本地备份。'];
const APP_VERSION='1.8.0';
const BACKUP_TIME_KEY='cardfolio_backup_exported_at';
let toastTimer,pwaRegistration=null,pwaStatus='独立 HTML 模式 · 核心功能可离线使用',reloadPending=false,modalDirty=false;
function toast(message){$('#toast').textContent=message;clearTimeout(toastTimer);toastTimer=setTimeout(()=>{$('#toast').textContent=''},4500)}
function pendingRewardText(e,actual){
 const p=actual?(credited(e)?eventPoints(e,true):0):pendingPoints(e);
 const cash=actual?(credited(e)?eventCash(e,true):0):pendingCash(e);
 return [p?`${fmtPoints(p)} ${programName(programForEvent(e))}`:'',cash?money(cash):''].filter(Boolean).join(' + ')||'—';
}
function mobileEvent(e){
 const bonus=BONUS_TYPES.includes(e.type),credit=e.type==='credit';
 const actual=bonus?pendingRewardText(e,true):credit?money(creditAmount(e)):credited(e)&&e.type!=='close'?(e.type==='fee'?'−':'')+money(num(e.amount)):'—';
 const pending=bonus?pendingRewardText(e,false):credit&&creditPending(e)?money(creditPending(e)):'—';
 return `<details class="mobile-event"><summary><div class="event-topline"><div class="event-card-name">${esc(cardName(e.cardId))}<br>${ownerBadge(ownerOf(cardById(e.cardId)))}</div>${tag(e.status)}</div>${typeTag(e.type)}<div class="event-heading">${esc(eventLabel(e))}</div><div class="event-date">实际日期 · ${esc(eventDateLabel(e))}</div><div class="event-amounts"><div><span>${e.type==='fee'?'实际支出':'已到账'}</span><strong class="received">${esc(actual)}</strong></div><div><span>待兑现</span><strong class="pending">${esc(pending)}</strong></div></div><span class="event-expand">展开详情与编辑 ↓</span></summary><div class="event-detail"><div class="divider"></div><div class="muted">登记日期 · ${fmtDate(e.date)}</div><p>${esc(itemNote(e)||'暂无补充说明')}</p><button class="btn" data-action="open-ledger" data-id="${esc(e.id)}">编辑这条记录</button></div></details>`;
}
function mobileLedger(page,ev){return `<div class="mobile-events">${page.items.map(mobileEvent).join('')}</div>${page.controls}${!ev.length?noData('还没有匹配的记录','open-ledger','新增奖励、年费或报销 →'):''}<p class="footnote">每页最多 50 条；搜索与导出覆盖全部记录。各积分项目独立统计。</p>`}
function renderMobileOverview(){
 const v=metrics(filterYear,'',ownerFilter),rows=pointsSummary(filterYear,ownerFilter),rem=reminders();
 const ranks=new Map(data.visualOrder.map((id,i)=>[id,i]));rows.sort((a,b)=>(ranks.get(a.id)??99999)-(ranks.get(b.id)??99999));
 const recent=data.events.filter(e=>visibleCardId(e.cardId)).slice().sort((a,b)=>eventDate(b).localeCompare(eventDate(a))).slice(0,4);
 $('#overview').innerHTML=`<div class="controls"><select class="field-compact" id="year-filter" aria-label="统计年份">${opts(yearOptions(),filterYear)}</select><span class="more" style="align-self:center">${esc(ownerFilter==='all'?'全家合计':ownerLabel(ownerFilter))}</span></div>
 <section class="mobile-hero"><div class="label">现金净收支 · USD</div><div class="value">${money(v.net)}</div><div class="sub">到账现金奖励 + 报销 + 年费退回 − 年费<br>积分单独记录，不折算现金</div></section>
 <div class="mobile-kpis">${metric('当前持卡',String(visibleCards().filter(c=>c.status!=='closed').length),'张主卡','blue')}${metric('积分项目',String(rows.length),'个项目独立统计','blue')}${metric('待兑现现金 / 报销',money(v.pendingCash+v.pendingCredit),'积分待兑现见下方项目卡片','blue')}</div>
 <div class="quick-actions" aria-label="快速登记"><button class="btn" data-action="open-card"><span class="icon-circle">＋</span>新增信用卡</button><button class="btn" data-action="open-ledger" data-type="signup_bonus"><span class="icon-circle">✦</span>登记 Bonus</button><button class="btn" data-action="open-ledger" data-type="fee"><span class="icon-circle">＄</span>登记年费</button><button class="btn" data-action="open-ledger" data-type="credit"><span class="icon-circle">↙</span>登记报销</button></div>
 <section class="outline section"><div class="section-head"><h2>近期提醒</h2><button class="minibtn" data-tab="timeline">查看全部 →</button></div>${rem.length?rem.slice(0,3).map(r=>`<div class="reminder"><div><strong>${esc(r.kind)} · ${esc(r.title)}</strong><small>${esc(r.note)}</small></div><div class="when">${fmtDate(r.date)}</div></div>`).join(''):noData('未来 90 天没有待办提醒')}</section>
 <section><div class="section-head"><h2>你的 Points & Miles</h2><button class="minibtn" data-tab="visuals">全部项目 →</button></div><div class="viz-cards">${rows.slice(0,4).map(r=>{const cat=vizProgramCategory(r.id,r.name);return `<article class="outline viz-card viz-card-${cat}"><div class="viz-card-title">${esc(r.name)}</div><div class="viz-card-main"><div class="viz-card-label">已到账奖励积分</div><div class="viz-card-number">${fmtPoints(r.posted)}</div></div><div class="viz-card-subgrid"><div class="viz-card-stat pending"><div class="label">待兑现</div><div class="value">${fmtPoints(r.pending)}</div></div><div class="viz-card-stat entries"><div class="label">奖励记录</div><div class="value">${r.entries}</div></div></div><button class="btn small" data-action="mobile-viz" data-id="${esc(r.id)}">查看明细 →</button></article>`}).join('')}</div>${!rows.length?noData('登记奖励后，积分项目会显示在这里','open-ledger','登记第一笔奖励'):''}</section>
 <section style="margin-top:24px"><div class="section-head"><h2>最近记录</h2><button class="minibtn" data-tab="ledger">全部流水 →</button></div><div class="mobile-events">${recent.map(mobileEvent).join('')}</div></section><p class="footnote">已到账积分是手动登记的奖励合计，不等于银行实时可用余额。各设备独立保存，请定期导出完整 JSON 备份。</p>`;
}
function renderMore(){
 const links=[['members','♙','家庭成员','管理 P1 / P2 与家庭账户'],['au','♧','副卡与 Bonus','关联副卡，奖励归主卡账户'],['programs','✦','常旅客项目设置','自定义项目与名称'],['benefits','◎','报销权益','额度、周期与到账记录'],['timeline','◷','时间线与提醒','实际日期、年费与截止日'],['data','↧','备份与说明','JSON 导入 / 导出与程序更新']];
 $('#more').innerHTML=`<div class="more-grid">${links.map(([id,icon,label,note])=>`<button class="btn more-link" data-tab="${id}"><span class="icon-circle">${icon}</span><span><strong>${label}</strong><small>${note}</small></span></button>`).join('')}</div><div class="help"><strong>数据只在这台设备</strong><br>电脑、手机、Safari 与主屏幕 App 请分别导入 JSON。相同网址不会自动同步数据。<br>Cardfolio v${APP_VERSION} · ${esc(pwaStatus)}</div>`;
}
function syncMobileNav(){
 const mainTabs=['overview','cards','ledger','visuals'];
 document.querySelectorAll('.mobile-nav [data-tab]').forEach(el=>{const active=el.dataset.tab===(mainTabs.includes(tab)?tab:'more');el.classList.toggle('active',active);if(active)el.setAttribute('aria-current','page');else el.removeAttribute('aria-current')});
}
function labelTables(){document.querySelectorAll('.screen.active .table-wrap table').forEach(table=>{const labels=[...table.querySelectorAll('thead th')].map(x=>x.textContent);table.querySelectorAll('tbody tr').forEach(row=>[...row.children].forEach((cell,i)=>{cell.dataset.label=labels[i]||''}))})}
function updateModalState(){const open=!!$('#modal-root .modal');document.body.classList.toggle('modal-open',open);$('.app').inert=open;$('.mobile-nav').inert=open;if(!open)modalDirty=false}
function confirmDiscard(){return !modalDirty||confirm('表单尚未保存。放弃这些输入并关闭吗？')}
function noteBackup(){
 try{localStorage.setItem(BACKUP_TIME_KEY,new Date().toISOString())}catch{}
 refreshBackupMeta();toast('备份已发起，请确认文件已保存到「文件」或其他安全位置。');
}
function backupDate(){try{const date=localStorage.getItem(BACKUP_TIME_KEY);return date&&Number.isFinite(Date.parse(date))?new Date(date).toLocaleString():'尚未导出'}catch{return '无法读取'}}
function refreshBackupMeta(){document.querySelectorAll('[data-backup-time]').forEach(el=>el.textContent=backupDate())}
function backupPanel(){return `<section class="outline section"><div class="section-head"><h2>本机备份与离线应用</h2><span class="tag blue">v${APP_VERSION}</span></div><p class="backup-meta">最近发起 JSON 导出 / 分享：<strong data-backup-time>${esc(backupDate())}</strong><br>这是导出操作时间，无法确认你是否已在系统中保存文件。</p><div class="controls"><button class="btn primary" data-action="export-json">下载完整 JSON</button><button class="btn" data-action="share-json">分享 / 保存备份</button><button class="btn" data-action="import-json">从「文件」导入 JSON</button></div><p class="footnote">导入前会验证并提示覆盖；建议先导出当前数据。JSON 始终由你手动保存与迁移，不会上传到 Cardfolio 服务器。电脑、手机、Safari 与主屏幕 App 的存储应分别检查；首次安装后请导入已有备份。</p><div class="highlight"><strong>本地记录不是永久可靠的云端备份。</strong>清理浏览器数据、系统回收空间、删除 App 或更换设备都可能丢失记录。请将 JSON 保存到你能找到的位置，并定期检查。<br><br>iPhone：Safari 分享菜单 →「添加到主屏幕」→ 打开新 App →「更多 / 备份与说明」→ 从「文件」导入 JSON。</div><p class="backup-meta" id="pwa-detail">${esc(pwaStatus)}</p><div class="controls"><button class="btn small" data-action="check-update">检查程序更新</button><button class="btn small" data-action="apply-update">安装已下载的更新</button></div><p class="footnote">更新只替换程序缓存，不删除 localStorage。部署到不同域名、协议或端口后，请重新手动导入备份。</p></section>`}
async function shareJSON(){
 const file=new File([JSON.stringify({...data,exportedAt:new Date().toISOString()},null,2)],`cardfolio-backup-${TODAY()}.json`,{type:'application/json'});
 if(navigator.canShare?.({files:[file]})&&navigator.share){try{await navigator.share({files:[file],title:'Cardfolio 完整备份'});noteBackup()}catch(err){if(err.name!=='AbortError')toast('系统分享未完成，请使用「下载完整 JSON」。')}return}
 exportJSON();
}
function showPWA(){
 const el=$('#pwa-detail');if(el)el.textContent=pwaStatus;
 const waiting=pwaRegistration?.waiting;
 $('#pwa-notice').innerHTML=waiting||reloadPending?`<strong>程序更新已就绪</strong> · 本地记录会保留。请先保存表单。<button class="btn small" data-action="apply-update">更新并重新打开</button>`:'';
 if(tab==='more')renderMore();
}
async function checkUpdate(){
 if(!pwaRegistration){toast(location.protocol==='file:'?'独立 HTML 不使用在线更新，请替换程序文件。':'离线应用尚未就绪，请联网后重新打开。');return}
 try{await pwaRegistration.update();toast(pwaRegistration.waiting?'更新已下载，可安装更新。':'已检查更新；有新版本时会显示提示。')}catch{toast('当前无法联网检查，已有离线程序仍可使用。')}showPWA();
}
function applyUpdate(){
 if(runtime.busy||modalDirty){toast('请先保存或关闭未保存的表单，再更新程序。');return}
 if(reloadPending){location.reload();return}
 if(pwaRegistration?.waiting)pwaRegistration.waiting.postMessage({type:'SKIP_WAITING'});else toast('暂无已下载的更新，请先检查更新。');
}
async function initPWA(){
 if(location.protocol==='file:'||!('serviceWorker'in navigator)||!isSecureContext){showPWA();return}
 try{
  pwaStatus='正在准备离线程序…';
  pwaRegistration=await navigator.serviceWorker.register('./sw.js',{scope:'./',updateViaCache:'none'});
  const ready=()=>{pwaStatus=navigator.onLine?'离线程序已就绪 · 记录保存在本机':'当前离线 · 可查看和保存本地记录';showPWA()};
  if(pwaRegistration.active)ready();
  const observeInstall=()=>{const worker=pwaRegistration.installing;if(!worker)return;const changed=()=>{if(worker.state==='installed'){if(navigator.serviceWorker.controller){pwaStatus='新版本已下载，等待你安装';showPWA()}else ready()}if(worker.state==='redundant'){pwaStatus='离线程序缓存未完成，请联网重试';showPWA()}};worker.addEventListener('statechange',changed);changed()};
  pwaRegistration.addEventListener('updatefound',observeInstall);observeInstall();
  navigator.serviceWorker.ready.then(ready);
  navigator.serviceWorker.addEventListener('controllerchange',()=>{if(!navigator.serviceWorker.controller)return;if(runtime.busy||modalDirty){reloadPending=true;pwaStatus='程序已更新；请保存表单后重新打开';showPWA()}else if(pwaRegistration.active&&document.documentElement.dataset.pwaControlled==='true'){location.reload()}else{document.documentElement.dataset.pwaControlled='true';ready()}});
  document.documentElement.dataset.pwaControlled=String(!!navigator.serviceWorker.controller);
  showPWA();
 }catch{pwaStatus='离线程序未能初始化；核心功能可继续使用，请检查 HTTPS 和部署文件';showPWA()}
}
document.addEventListener('input',e=>{if(e.target.closest('#modal-root form'))modalDirty=true},true);
document.addEventListener('change',e=>{if(e.target.closest('#modal-root form'))modalDirty=true},true);
document.addEventListener('click',e=>{
 const el=e.target.closest('[data-action]');if(!el)return;
 const action=el.dataset.action;
 if((action.startsWith('open-')||action==='view-card')&&$('#modal-root form')&&modalDirty){if(!confirmDiscard()){e.preventDefault();e.stopImmediatePropagation();return}modalDirty=false}
 if(action==='mobile-viz'){visualSelected=el.dataset.id;visualYear=filterYear;runtime.dirty.add('visuals');setTab('visuals');requestAnimationFrame(()=>$('#visuals .viz-detail')?.scrollIntoView({block:'start'}))}
 else if(action==='share-json')shareJSON();else if(action==='check-update')checkUpdate();else if(action==='apply-update')applyUpdate();
},true);
window.addEventListener('beforeunload',e=>{if(modalDirty||runtime.busy){e.preventDefault();e.returnValue=''}});
new MutationObserver(()=>{updateModalState()}).observe($('#modal-root'),{childList:true});
new MutationObserver(labelTables).observe($('.main'),{childList:true,subtree:true});
compactMedia.addEventListener('change',()=>{runtime.dirty.add('overview');runtime.dirty.add('ledger');renderCurrent();syncMobileNav()});
function updateViewport(){
 const vv=window.visualViewport;
 document.documentElement.style.setProperty('--viewport-height',(vv?.height||innerHeight)+'px');
 document.documentElement.style.setProperty('--viewport-top',(vv?.offsetTop||0)+'px');
 const editing=/^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement?.tagName||'');
 document.body.classList.toggle('keyboard-open',editing&&!!vv&&vv.scale<=1.05&&innerHeight-vv.height>130);
}
window.visualViewport?.addEventListener('resize',updateViewport);window.visualViewport?.addEventListener('scroll',updateViewport);window.addEventListener('resize',updateViewport);updateViewport();
document.addEventListener('focusin',updateViewport);document.addEventListener('focusout',()=>requestAnimationFrame(updateViewport));
window.addEventListener('online',()=>{if(pwaRegistration){pwaStatus='已恢复网络 · 检查程序更新';showPWA();pwaRegistration.update().catch(()=>{})}});
window.addEventListener('offline',()=>{pwaStatus=pwaRegistration?'当前离线 · 可查看和保存本地记录':'当前离线 · 请勿清理浏览器本地记录';showPWA()});
document.addEventListener('visibilitychange',()=>{if(!document.hidden&&pwaRegistration&&navigator.onLine)pwaRegistration.update().catch(()=>{})});
initPWA();
